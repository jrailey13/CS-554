# React + Vite

This template provides a SUPER minimal setup to get React working in Vite with HMR and some ESLint rules.

```
npm i -g degit
npx degit g00gol/vite-super-minimal-react FOLDER_NAME
```
