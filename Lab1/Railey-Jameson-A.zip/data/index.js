import postDataFunctions from './posts.js'
import commentDataFunctions from './comments.js'

export const postData = postDataFunctions;
export const commentData = commentDataFunctions;