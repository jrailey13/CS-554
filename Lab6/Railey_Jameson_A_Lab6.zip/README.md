All of the client side functionality is in the 'react-client' directory. All of the server side functionality is in the 'server' directory.

To run the lab:
- Go into the server directory and enter the command 'npm start'
- Open a new terminal
- Go into the react-client directory and enter the command 'npm run dev'
- Use the provided link to access the react application
- There is a seed file in the server directory if you need/want data for testing